LSE CENTER WEBSITE
==================

Website tĩnh responsive, đã chuẩn bị sẵn:
- index.html
- styles.css
- assets/ (logo + 3 hình học liệu)
- robots.txt
- sitemap.xml

Thông tin đã dùng:
Tên: LSE – Trung tâm Khai phóng và Phát triển Kỹ năng
Địa chỉ: 422 Vĩnh Hưng, Hà Nội
Điện thoại: 0842 962 789
Email: ttnt.ai.nhom7@gmail.com
Facebook: https://www.facebook.com/share/18YPJRvfnx/

Mục tiêu domain:
https://lse.edu.vn/

LƯU Ý:
1. Gói này KHÔNG thể tự đăng ký/mua tên miền lse.edu.vn. Tên miền phải được đăng ký với một Nhà đăng ký tên miền .VN.
2. Sau khi sở hữu domain, deploy toàn bộ thư mục lên hosting/Vercel/Netlify/Cloudflare Pages.
3. Trỏ DNS của lse.edu.vn về hosting.
4. Khi https://lse.edu.vn/ đã mở được công khai, dùng URL này trong Meta.
5. Nếu Meta yêu cầu xác minh domain, lấy mã xác minh do Meta cấp và thêm vào index.html hoặc xác minh bằng DNS TXT theo hướng dẫn của Meta.
